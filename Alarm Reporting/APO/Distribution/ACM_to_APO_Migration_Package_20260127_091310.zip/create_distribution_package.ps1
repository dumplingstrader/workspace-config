<#
.SYNOPSIS
    Creates distribution package for ACM to APO Migration project deliverables
.DESCRIPTION
    Organizes project files into logical folders and creates a timestamped zip archive
    for distribution, including all documentation, tools, and reference materials.
.NOTES
    Created: January 27, 2026
    Project: ACM to APO Migration Whitepaper & Conference Submission
#>

[CmdletBinding()]
param(
    [Parameter()]
    [switch]$OrganizeOnly,
    
    [Parameter()]
    [switch]$ZipOnly,
    
    [Parameter()]
    [string]$OutputPath = ".\Distribution"
)

# Color output functions
function Write-Success { param($Message) Write-Host "[SUCCESS] $Message" -ForegroundColor Green }
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Warning { param($Message) Write-Host "[WARNING] $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

# Get script location
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptPath

Write-Info "ACM to APO Migration - Distribution Package Creator"
Write-Info "Current directory: $ScriptPath"
Write-Host ""

# Define folder structure
$FolderStructure = @{
    "1_Deliverables" = @(
        "Conference_Submission",
        "Whitepaper",
        "Checklist"
    )
    "2_Source_Documents" = @(
        "Working_Versions",
        "Barbara_Feedback"
    )
    "3_Reference_Materials" = @(
        "Honeywell_Documentation",
        "Industry_Standards",
        "Case_Studies"
    )
    "4_Scripts_Tools" = @()
    "5_Archive" = @(
        "Extracted_Text",
        "Old_Versions"
    )
}

# File mapping (source -> destination)
$FileMapping = @{
    # 1_Deliverables/Conference_Submission
    "Executive_Summary_Conference_Submission.txt" = "1_Deliverables\Conference_Submission"
    "Presentation_Outline_Conference.md" = "1_Deliverables\Conference_Submission"
    "Presentation_Outline_Conference.docx" = "1_Deliverables\Conference_Submission"
    "DynAMo Standard Sync and Alternative Active Sync v3.2.pptx" = "1_Deliverables\Conference_Submission"
    
    # 1_Deliverables/Whitepaper
    "ACM_to_APO_Migration_Whitepaper_Outline.md" = "1_Deliverables\Whitepaper"
    "ACM_to_APO_Migration_Whitepaper_Outline.docx" = "1_Deliverables\Whitepaper"
    
    # 1_Deliverables/Checklist
    "ACM_to_APO_Migration_Comprehensive_Checklist.xlsx" = "1_Deliverables\Checklist"
    "CHECKLIST_CREATION_SUMMARY.md" = "1_Deliverables\Checklist"
    "CHECKLIST_CREATION_SUMMARY.pdf" = "1_Deliverables\Checklist"
    
    # 2_Source_Documents/Working_Versions
    "APO_Deployment_Workflow_Checklist.xlsx" = "2_Source_Documents\Working_Versions"
    
    # 2_Source_Documents/Barbara_Feedback
    "ACM_to_APO_Migration_Whitepaper_Outline_BKS edits.docx" = "2_Source_Documents\Barbara_Feedback"
    "Potential additions to the Standard HAM delivery (Barbara Schubert).docx" = "2_Source_Documents\Barbara_Feedback"
    
    # 3_Reference_Materials/Honeywell_Documentation
    "Alarm Performance Optimizer Configuration Guide.pdf" = "3_Reference_Materials\Honeywell_Documentation"
    "Alarm Performance Optimizer Installation Guide.pdf" = "3_Reference_Materials\Honeywell_Documentation"
    "GuardianNewsletterQ32025.pdf" = "3_Reference_Materials\Honeywell_Documentation"
    
    # 3_Reference_Materials/Industry_Standards
    "honeywell-alarm-management-standards-whitepaper.pdf" = "3_Reference_Materials\Industry_Standards"
    
    # 3_Reference_Materials/Case_Studies
    "MPC APO Deployment Cookbook.docx" = "3_Reference_Materials\Case_Studies"
    "O-791428_ APO training.docx" = "3_Reference_Materials\Case_Studies"
    "SuccessStory_IrvingOil_AlarmManagement1.pdf" = "3_Reference_Materials\Case_Studies"
    
    # 4_Scripts_Tools
    "create_comprehensive_checklist.py" = "4_Scripts_Tools"
    "create_comprehensive_checklist_v2.py" = "4_Scripts_Tools"
    "read_checklist.py" = "4_Scripts_Tools"
    
    # 5_Archive/Extracted_Text
    "BKS_edits_extracted.txt" = "5_Archive\Extracted_Text"
    "PPTX_extracted.txt" = "5_Archive\Extracted_Text"
    
    # Root level documentation
    "PROJECT_HANDOFF_SUMMARY.md" = ""
    "APO_Documentation_Analysis_Summary.md" = ""
}

# Function to create folder structure
function New-FolderStructure {
    Write-Info "Creating organized folder structure..."
    
    foreach ($TopFolder in $FolderStructure.Keys) {
        $TopPath = Join-Path $ScriptPath $TopFolder
        if (-not (Test-Path $TopPath)) {
            New-Item -ItemType Directory -Path $TopPath -Force | Out-Null
            Write-Success "Created: $TopFolder"
        }
        
        foreach ($SubFolder in $FolderStructure[$TopFolder]) {
            $SubPath = Join-Path $TopPath $SubFolder
            if (-not (Test-Path $SubPath)) {
                New-Item -ItemType Directory -Path $SubPath -Force | Out-Null
                Write-Success "Created: $TopFolder\$SubFolder"
            }
        }
    }
    
    Write-Host ""
}

# Function to organize files
function Move-FilesToStructure {
    Write-Info "Organizing files into folder structure..."
    $MoveCount = 0
    $SkipCount = 0
    
    foreach ($SourceFile in $FileMapping.Keys) {
        $SourcePath = Join-Path $ScriptPath $SourceFile
        $DestFolder = $FileMapping[$SourceFile]
        
        if ($DestFolder -eq "") {
            # Keep in root
            continue
        }
        
        $DestPath = Join-Path $ScriptPath $DestFolder
        $DestFilePath = Join-Path $DestPath (Split-Path $SourceFile -Leaf)
        
        if (Test-Path $SourcePath) {
            # Only move if not already in correct location
            if ($SourcePath -ne $DestFilePath) {
                try {
                    Move-Item -Path $SourcePath -Destination $DestPath -Force -ErrorAction Stop
                    Write-Success "Moved: $SourceFile → $DestFolder"
                    $MoveCount++
                }
                catch {
                    Write-Warning "Failed to move: $SourceFile (may be in use)"
                    $SkipCount++
                }
            }
        }
        else {
            Write-Warning "Not found: $SourceFile"
        }
    }
    
    Write-Host ""
    Write-Info "Files organized: $MoveCount moved, $SkipCount skipped"
    Write-Host ""
}

# Function to create distribution package
function New-DistributionPackage {
    param([string]$OutputPath)
    
    Write-Info "Creating distribution package..."
    
    # Create output directory if needed
    if (-not (Test-Path $OutputPath)) {
        New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    }
    
    # Generate timestamp
    $Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $ZipFileName = "ACM_to_APO_Migration_Package_$Timestamp.zip"
    $ZipPath = Join-Path $OutputPath $ZipFileName
    
    # Items to include in zip
    $ItemsToZip = @(
        "1_Deliverables",
        "2_Source_Documents",
        "3_Reference_Materials",
        "4_Scripts_Tools",
        "5_Archive",
        "PROJECT_HANDOFF_SUMMARY.md",
        "APO_Documentation_Analysis_Summary.md",
        "DISTRIBUTION_GUIDE.md",
        "organize_files.ps1",
        "create_distribution_package.ps1",
        "image"
    )
    
    # Create temp staging directory
    $StagingPath = Join-Path $OutputPath "staging_temp"
    if (Test-Path $StagingPath) {
        Remove-Item -Path $StagingPath -Recurse -Force
    }
    New-Item -ItemType Directory -Path $StagingPath -Force | Out-Null
    
    # Copy items to staging
    Write-Info "Copying files to staging area..."
    foreach ($Item in $ItemsToZip) {
        $SourcePath = Join-Path $ScriptPath $Item
        if (Test-Path $SourcePath) {
            $DestPath = Join-Path $StagingPath $Item
            Copy-Item -Path $SourcePath -Destination $DestPath -Recurse -Force
            Write-Success "Copied: $Item"
        }
    }
    
    # Create README for the package
    $ReadmeContent = @"
# ACM to APO Migration - Distribution Package
**Generated**: $(Get-Date -Format "MMMM dd, yyyy HH:mm:ss")
**Version**: Conference Submission & Comprehensive Checklist

## Package Contents

### 1_Deliverables/
Final outputs ready for distribution:
- **Conference_Submission/** - Honeywell Users Conference 2026 materials
  - Executive summary (1097 chars, conference-ready)
  - Presentation outline (20 slides, 50 minutes)
  - DynAMo presentation (Alternative Active Sync methodology)
- **Whitepaper/** - Complete whitepaper outline (master document)
- **Checklist/** - Comprehensive migration checklist (250+ tasks, 11 sheets)

### 2_Source_Documents/
Working documents and feedback:
- **Working_Versions/** - Barbara's original workflow checklist
- **Barbara_Feedback/** - BKS-edited versions with 40+ changes integrated

### 3_Reference_Materials/
Supporting documentation:
- **Honeywell_Documentation/** - APO installation/configuration guides
- **Industry_Standards/** - ISA 18.2, EEMUA 191 standards
- **Case_Studies/** - MPC cookbook, Irving Oil success story, training materials

### 4_Scripts_Tools/
Python automation tools:
- create_comprehensive_checklist_v2.py (primary generator)
- create_comprehensive_checklist.py (v1)
- read_checklist.py (Excel validation utility)

### 5_Archive/
Historical versions and extracted content:
- **Extracted_Text/** - Text extractions from edited documents
- **Old_Versions/** - (reserved for version history)

## Key Documents

**PRIMARY MASTER FILE**: 1_Deliverables/Whitepaper/ACM_to_APO_Migration_Whitepaper_Outline.md
- 13 main sections + 10 appendices + 7 case studies
- All Barbara's feedback integrated (40+ changes)
- 60-80 pages estimated when fully written

**CONFERENCE SUBMISSION**: 1_Deliverables/Conference_Submission/Executive_Summary_Conference_Submission.txt
- Ready for Honeywell Users Conference website submission
- 1097 characters (under 1100 limit)
- Barbara Schubert NOT mentioned (Honeywell sensitivity)

**COMPREHENSIVE CHECKLIST**: 1_Deliverables/Checklist/ACM_to_APO_Migration_Comprehensive_Checklist.xlsx
- 11-sheet workbook with 250+ tasks
- Phase 0-9 structure (Barbara's preferred format)
- Auto-formatting, status dropdowns, conditional formatting

## Project Context

**ACM End of Support**: December 31, 2027
**Subject Matter Expert**: Barbara Schubert (27 years alarm management expertise)
**Target Audience**: Control engineers, alarm management professionals, project managers
**Urgency**: Hundreds of plants worldwide must migrate by end of 2027

## Critical Success Factors

1. Database health assessment (6-12 months pre-migration)
2. License sizing (exclude 30-40% ghost tags)
3. Hierarchy alignment (ACM/M&R/EAS compatibility)
4. Custom solutions (health checks, Alternative Active Sync)
5. Training & change management

## Usage

1. Review PROJECT_HANDOFF_SUMMARY.md for complete project context
2. Start with 1_Deliverables/ for conference submission or client delivery
3. Use 4_Scripts_Tools/ to regenerate checklist from whitepaper outline
4. Reference 3_Reference_Materials/ for technical details

## Contact

For questions about this package or project continuation, refer to:
- PROJECT_HANDOFF_SUMMARY.md (project overview and status)
- CHECKLIST_CREATION_SUMMARY.md (how checklist was created)
- APO_Documentation_Analysis_Summary.md (vendor gap analysis)

---
**Note**: This package contains all materials needed for conference presentation, 
whitepaper writing, and migration project execution.
"@
    
    $ReadmeContent | Out-File -FilePath (Join-Path $StagingPath "README.txt") -Encoding UTF8
    Write-Success "Created: README.txt"
    
    Write-Host ""
    Write-Info "Creating ZIP archive..."
    
    # Remove old zip if exists
    if (Test-Path $ZipPath) {
        Remove-Item -Path $ZipPath -Force
    }
    
    # Create zip archive
    try {
        Compress-Archive -Path "$StagingPath\*" -DestinationPath $ZipPath -CompressionLevel Optimal -Force
        Write-Success "Created: $ZipFileName"
        
        # Get zip file size
        $ZipSize = (Get-Item $ZipPath).Length / 1MB
        Write-Info "Package size: $([math]::Round($ZipSize, 2)) MB"
        Write-Info "Location: $ZipPath"
    }
    catch {
        Write-Error "Failed to create ZIP archive: $_"
        return
    }
    finally {
        # Cleanup staging
        if (Test-Path $StagingPath) {
            Remove-Item -Path $StagingPath -Recurse -Force
        }
    }
    
    Write-Host ""
    Write-Success "Distribution package created successfully!"
}

# Main execution
try {
    if (-not $ZipOnly) {
        New-FolderStructure
        Move-FilesToStructure
    }
    
    if (-not $OrganizeOnly) {
        New-DistributionPackage -OutputPath $OutputPath
    }
    
    Write-Host ""
    Write-Success "Process completed!"
    Write-Info "Next steps:"
    if (-not $OrganizeOnly) {
        Write-Host "  1. Review distribution package in: $OutputPath" -ForegroundColor Cyan
        Write-Host "  2. Test ZIP contents before external distribution" -ForegroundColor Cyan
        Write-Host "  3. Use organized folder structure for continued development" -ForegroundColor Cyan
    }
    else {
        Write-Host "  1. Files organized into folder structure" -ForegroundColor Cyan
        Write-Host "  2. Run without -OrganizeOnly to create ZIP package" -ForegroundColor Cyan
    }
}
catch {
    Write-Error "Script failed: $_"
    exit 1
}
